package com.example.demo.Controller;
import com.example.demo.model.*;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/tasks")
public class TaskController {
    @Autowired
    private TaskRepository taskRepository;

    @GetMapping
    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Task> getTaskById(@PathVariable String id) {
        return taskRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping
    public Task createTask(@RequestBody Task task) {
        return taskRepository.save(task);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTask(@PathVariable String id) {
        taskRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/{id}/execute")
    public ResponseEntity<TaskExecution> executeTask(@PathVariable String id) {
        return taskRepository.findById(id).map(task -> {
            TaskExecution execution = new TaskExecution();
            execution.setStartTime(new Date());

            try {
                Process process = Runtime.getRuntime().exec(new String[]{"cmd.exe", "/c", task.getCommand()});
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String output = reader.lines().collect(Collectors.joining("\n"));
                execution.setOutput(output);
                process.waitFor();
            } catch (Exception e) {
                execution.setOutput("Execution failed: " + e.getMessage());
            }

            execution.setEndTime(new Date());
            task.getTaskExecutions().add(execution);
            taskRepository.save(task);
            return ResponseEntity.ok(execution);
        }).orElse(ResponseEntity.notFound().build());
    }
}
